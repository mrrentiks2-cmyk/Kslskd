package com.neondrift.wallpaper;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

/** Боке: размытые огни медленно всплывают и мерцают. */
final class BokehScene extends Scene {
    private static final int BURST = 48;

    private int n, total;
    private float[] x, y, r, vx, vy, ph, life;
    private int[] ci;
    private Bitmap[] discs, sparks;
    private final Paint bg = new Paint();
    private final Paint add = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);

    @Override
    protected void onSetup() {
        n = U.clamp(Math.round(30 * cfg.density * areaK() + 10), 10, 90);
        total = n + BURST;
        x = new float[total];
        y = new float[total];
        r = new float[total];
        vx = new float[total];
        vy = new float[total];
        ph = new float[total];
        life = new float[total];
        ci = new int[total];
        for (int i = 0; i < n; i++) {
            x[i] = U.rand(0, w);
            y[i] = U.rand(0, h);
            float k = U.R.nextFloat();
            r[i] = scale * (8f + 70f * k * k);
            vx[i] = U.rand(-8f, 8f) * scale;
            vy[i] = -U.rand(6f, 22f) * scale;
            ph[i] = U.rand(0, U.TAU);
            life[i] = -1f;
            ci[i] = U.R.nextInt(3);
        }
        for (int i = n; i < total; i++) life[i] = 0f;
        discs = new Bitmap[]{U.bokeh(pal.a), U.bokeh(pal.b), U.bokeh(pal.c)};
        sparks = new Bitmap[]{U.glow(pal.a, true), U.glow(pal.b, true), U.glow(pal.c, true)};
        bg.setShader(U.vgrad(0, h, new int[]{pal.bgTop, pal.bgBottom, U.mix(pal.bgBottom, pal.a, 0.15f)},
                new float[]{0f, 0.6f, 1f}));
        add.setXfermode(U.add());
    }

    @Override
    protected void update(float dt, float realDt) {
        float decay = (float) Math.exp(-1.8 * dt);
        for (int i = 0; i < total; i++) {
            if (life[i] == 0f) continue;
            x[i] += vx[i] * dt;
            y[i] += vy[i] * dt + U.sin(time * 0.6f + ph[i]) * 4f * scale * dt;
            if (life[i] < 0f) {
                if (y[i] + r[i] < 0f) {
                    y[i] = h + r[i];
                    x[i] = U.rand(0, w);
                }
                if (x[i] < -r[i]) x[i] += w + 2 * r[i];
                else if (x[i] > w + r[i]) x[i] -= w + 2 * r[i];
            } else {
                vx[i] *= decay;
                vy[i] = vy[i] * decay - 10f * scale * dt;
                life[i] = Math.max(0f, life[i] - dt);
            }
        }
    }

    @Override
    protected void draw(Canvas c) {
        c.drawRect(0, 0, w, h, bg);
        float shift = -par() * w * 0.06f;
        for (int i = 0; i < total; i++) {
            if (life[i] == 0f) continue;
            float px = x[i] + shift * (r[i] / (40f * scale));
            if (life[i] < 0f) {
                int a = Math.round(150 + 70 * U.sin(time * 0.9f + ph[i]));
                tmp.set(px - r[i], y[i] - r[i], px + r[i], y[i] + r[i]);
                add.setAlpha(a);
                c.drawBitmap(discs[ci[i]], null, tmp, add);
            } else {
                float k = Math.min(1f, life[i] / 1.2f);
                float rr = r[i] * (0.6f + 0.4f * k);
                tmp.set(px - rr, y[i] - rr, px + rr, y[i] + rr);
                add.setAlpha(Math.round(255 * k));
                c.drawBitmap(sparks[ci[i]], null, tmp, add);
            }
        }
    }

    @Override
    protected void onTouch(float tx, float ty, int action) {
        if (!isPress(action)) return;
        int spawned = 0;
        for (int i = n; i < total && spawned < 14; i++) {
            if (life[i] != 0f) continue;
            float a = U.rand(0, U.TAU), s = U.rand(60f, 240f) * scale;
            x[i] = tx;
            y[i] = ty;
            vx[i] = U.cos(a) * s;
            vy[i] = U.sin(a) * s;
            r[i] = U.rand(6f, 20f) * scale;
            ph[i] = U.rand(0, U.TAU);
            life[i] = U.rand(0.9f, 1.5f);
            ci[i] = U.R.nextInt(3);
            spawned++;
        }
    }
}
