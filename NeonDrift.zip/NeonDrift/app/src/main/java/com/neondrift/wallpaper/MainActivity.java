package com.neondrift.wallpaper;

import android.app.Activity;
import android.app.WallpaperInfo;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

/** Экран настройки: живое превью, выбор сцены, палитры, параметров и установка обоев. */
public class MainActivity extends Activity {
    private static final int REQ_PHOTO = 11, REQ_VIDEO = 12;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final int BG = 0xFF0B0814;
    private static final int SURFACE = 0xFF151022;
    private static final int LINE = 0xFF2A2140;
    private static final int TEXT = 0xFFF1ECFF;
    private static final int MUTED = 0xFF9B90BD;

    private static final String[] OVERLAYS = {"none", "snow", "sparks", "bubbles", "rain"};
    private static final String[] OVERLAY_NAMES = {"Нет", "Снег", "Искры", "Пузыри", "Дождь"};

    private WallConfig draft;
    private String selected;
    private float dens;
    private int thumbGen;

    private ScenePreviewView preview;
    private VideoPreviewView videoPreview;
    private TextView videoHint, sceneTitle, sceneSub, applyBtn, paletteName, pickPhotoBtn, pickVideoBtn;
    private TextView speedVal, densityVal, brightVal;
    private SeekBar speedBar, densityBar, brightBar;
    private Switch fpsSw, touchSw, parallaxSw;
    private View paletteSection, photoSection, videoSection, tuneSection;

    private final HashMap<String, ImageView> thumbs = new HashMap<>();
    private final HashMap<String, GradientDrawable> cardBorders = new HashMap<>();
    private final ArrayList<PaletteChip> chips = new ArrayList<>();
    private final ArrayList<TextView> overlayChips = new ArrayList<>();

    // ------------------------------------------------------------------ жизненный цикл

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        dens = getResources().getDisplayMetrics().density;
        draft = WallConfig.load(this);
        selected = getSharedPreferences("ui", MODE_PRIVATE).getString("selected", draft.scene);
        if (!known(selected)) selected = "city";

        Window win = getWindow();
        win.setStatusBarColor(BG);
        win.setNavigationBarColor(BG);
        setContentView(buildUi());
        syncControls();
        refresh(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Scenes.isVideo(selected)) videoPreview.resume();
        else preview.setRunning(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        preview.setRunning(false);
        videoPreview.pause();
    }

    @Override
    protected void onDestroy() {
        videoPreview.stop();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ интерфейс

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(20), dp(20), dp(36));
        scroll.addView(col, new FrameLayout.LayoutParams(MATCH, WRAP));

        TextView logo = text("NEON DRIFT", 24, TEXT, false);
        logo.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        logo.setLetterSpacing(0.24f);
        col.addView(logo);
        TextView tag = text("живые обои", 13, MUTED, false);
        tag.setLetterSpacing(0.1f);
        col.addView(tag, margins(WRAP, WRAP, 0, dp(2)));

        col.addView(buildPreview());

        sceneTitle = text("", 19, TEXT, true);
        sceneTitle.setGravity(Gravity.CENTER);
        col.addView(sceneTitle, margins(MATCH, WRAP, 0, dp(16)));
        sceneSub = text("", 13, MUTED, false);
        sceneSub.setGravity(Gravity.CENTER);
        col.addView(sceneSub, margins(MATCH, WRAP, 0, dp(4)));

        applyBtn = text("Установить обои", 16, BG, true);
        applyBtn.setGravity(Gravity.CENTER);
        applyBtn.setPadding(dp(16), dp(17), dp(16), dp(17));
        applyBtn.setOnClickListener(v -> apply());
        col.addView(applyBtn, margins(MATCH, WRAP, 0, dp(20)));

        col.addView(label("СЦЕНА"), margins(MATCH, WRAP, 0, dp(30)));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (String id : Scenes.IDS) row.addView(sceneCard(id));
        hs.addView(row);
        col.addView(hs, margins(MATCH, WRAP, 0, dp(12)));

        paletteSection = buildPaletteSection();
        col.addView(paletteSection);
        photoSection = buildPhotoSection();
        col.addView(photoSection);
        videoSection = buildVideoSection();
        col.addView(videoSection);
        tuneSection = buildTuneSection();
        col.addView(tuneSection);

        TextView foot = text("Обои рисуются только когда рабочий стол на экране. "
                + "В режиме энергосбережения частота кадров сама падает до 30.", 12, MUTED, false);
        foot.setLineSpacing(0, 1.25f);
        col.addView(foot, margins(MATCH, WRAP, 0, dp(26)));
        return scroll;
    }

    private View buildPreview() {
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int pw = Math.round(Math.min(screenW * 0.62f, dp(300)));
        int ph = Math.round(pw * 2.05f);
        float radius = dp(28);

        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(0xFF000000);
        frame.setOutlineProvider(rounded(radius));
        frame.setClipToOutline(true);

        preview = new ScenePreviewView(this);
        frame.addView(preview, new FrameLayout.LayoutParams(MATCH, MATCH));
        videoPreview = new VideoPreviewView(this);
        videoPreview.setVisibility(View.GONE);
        frame.addView(videoPreview, new FrameLayout.LayoutParams(MATCH, MATCH));

        videoHint = text("Выберите видео ниже", 14, MUTED, false);
        videoHint.setGravity(Gravity.CENTER);
        videoHint.setVisibility(View.GONE);
        frame.addView(videoHint, new FrameLayout.LayoutParams(MATCH, MATCH));

        View border = new View(this);
        border.setBackground(stroke(Color.TRANSPARENT, LINE, dp(1), radius));
        frame.addView(border, new FrameLayout.LayoutParams(MATCH, MATCH));

        View island = new View(this);
        island.setBackground(fill(0xFF000000, dp(10)));
        FrameLayout.LayoutParams il = new FrameLayout.LayoutParams(Math.round(pw * 0.28f), dp(14),
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        il.topMargin = dp(10);
        frame.addView(island, il);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(pw, ph);
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        lp.topMargin = dp(22);
        frame.setLayoutParams(lp);
        return frame;
    }

    private View sceneCard(final String id) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);

        float r = dp(16);
        FrameLayout thumbFrame = new FrameLayout(this);
        thumbFrame.setBackgroundColor(SURFACE);
        thumbFrame.setOutlineProvider(rounded(r));
        thumbFrame.setClipToOutline(true);
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        thumbFrame.addView(iv, new FrameLayout.LayoutParams(MATCH, MATCH));
        View border = new View(this);
        GradientDrawable bd = stroke(Color.TRANSPARENT, LINE, dp(1), r);
        border.setBackground(bd);
        thumbFrame.addView(border, new FrameLayout.LayoutParams(MATCH, MATCH));
        card.addView(thumbFrame, new LinearLayout.LayoutParams(dp(92), dp(164)));

        TextView name = text(Scenes.title(id), 12, TEXT, false);
        name.setGravity(Gravity.CENTER);
        name.setMaxLines(2);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(dp(92), WRAP);
        nl.topMargin = dp(8);
        card.addView(name, nl);

        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(WRAP, WRAP);
        cl.rightMargin = dp(12);
        card.setLayoutParams(cl);
        card.setOnClickListener(v -> select(id));
        thumbs.put(id, iv);
        cardBorders.put(id, bd);
        return card;
    }

    private View buildPaletteSection() {
        LinearLayout sec = vertical();
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(label("ПАЛИТРА"));
        paletteName = text("", 12, TEXT, false);
        head.addView(paletteName, margins(WRAP, WRAP, dp(10), 0));
        sec.addView(head, margins(MATCH, WRAP, 0, dp(28)));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < Palette.ALL.length; i++) {
            final int index = i;
            PaletteChip chip = new PaletteChip(this, Palette.ALL[i]);
            chip.setOnClickListener(v -> {
                draft.paletteIndex = index;
                refresh(true);
            });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(dp(46), dp(46));
            l.rightMargin = dp(10);
            row.addView(chip, l);
            chips.add(chip);
        }
        hs.addView(row);
        sec.addView(hs, margins(MATCH, WRAP, 0, dp(12)));
        return sec;
    }

    private View buildPhotoSection() {
        LinearLayout sec = vertical();
        sec.addView(label("ФОТО"), margins(MATCH, WRAP, 0, dp(28)));
        pickPhotoBtn = secondaryButton("Выбрать фото", v -> pick("image/*", REQ_PHOTO));
        sec.addView(pickPhotoBtn, margins(MATCH, WRAP, 0, dp(12)));
        sec.addView(text("Эффект поверх фото", 13, MUTED, false), margins(MATCH, WRAP, 0, dp(18)));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < OVERLAYS.length; i++) {
            final String key = OVERLAYS[i];
            TextView chip = text(OVERLAY_NAMES[i], 14, TEXT, false);
            chip.setPadding(dp(16), dp(9), dp(16), dp(9));
            chip.setOnClickListener(v -> {
                draft.overlay = key;
                refresh(false);
                preview.rebuild();
            });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(WRAP, WRAP);
            l.rightMargin = dp(8);
            row.addView(chip, l);
            overlayChips.add(chip);
        }
        hs.addView(row);
        sec.addView(hs, margins(MATCH, WRAP, 0, dp(10)));
        return sec;
    }

    private View buildVideoSection() {
        LinearLayout sec = vertical();
        sec.addView(label("ВИДЕО"), margins(MATCH, WRAP, 0, dp(28)));
        pickVideoBtn = secondaryButton("Выбрать видео", v -> pick("video/*", REQ_VIDEO));
        sec.addView(pickVideoBtn, margins(MATCH, WRAP, 0, dp(12)));
        TextView note = text("Ролик крутится по кругу без звука и подгоняется под экран с обрезкой краёв. "
                + "Чем короче видео и ниже его разрешение, тем меньше расход батареи.", 12, MUTED, false);
        note.setLineSpacing(0, 1.25f);
        sec.addView(note, margins(MATCH, WRAP, 0, dp(12)));
        return sec;
    }

    private View buildTuneSection() {
        LinearLayout sec = vertical();
        sec.addView(label("НАСТРОЙКИ"), margins(MATCH, WRAP, 0, dp(28)));
        LinearLayout card = vertical();
        card.setBackground(fill(SURFACE, dp(20)));
        card.setPadding(dp(18), dp(8), dp(18), dp(10));
        sec.addView(card, margins(MATCH, WRAP, 0, dp(12)));

        speedVal = valueText();
        speedBar = new SeekBar(this);
        addSlider(card, "Скорость", speedBar, speedVal);
        speedBar.setOnSeekBarChangeListener(new Seek() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (!user) return;
                draft.speed = 0.2f + p / 100f * 2.3f;
                updateLabels();
            }
        });

        densityVal = valueText();
        densityBar = new SeekBar(this);
        addSlider(card, "Плотность", densityBar, densityVal);
        densityBar.setOnSeekBarChangeListener(new Seek() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (!user) return;
                draft.density = 0.4f + p / 100f * 1.6f;
                updateLabels();
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                preview.rebuild();
            }
        });

        brightVal = valueText();
        brightBar = new SeekBar(this);
        addSlider(card, "Яркость", brightBar, brightVal);
        brightBar.setOnSeekBarChangeListener(new Seek() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (!user) return;
                draft.brightness = 0.35f + p / 100f * 0.65f;
                updateLabels();
            }
        });

        fpsSw = switchRow(card, "Плавность 60 кадров/с", "Выключите — будет 30 кадров/с и меньше расход");
        fpsSw.setOnCheckedChangeListener((b, on) -> draft.fps = on ? 60 : 30);
        touchSw = switchRow(card, "Реакция на касания", "Сцена отвечает на тапы по рабочему столу");
        touchSw.setOnCheckedChangeListener((b, on) -> draft.touch = on);
        parallaxSw = switchRow(card, "Параллакс", "Сцена сдвигается, когда листаете экраны");
        parallaxSw.setOnCheckedChangeListener((b, on) -> draft.parallax = on);
        return sec;
    }

    // ------------------------------------------------------------------ состояние

    private void select(String id) {
        if (id.equals(selected)) return;
        selected = id;
        getSharedPreferences("ui", MODE_PRIVATE).edit().putString("selected", id).apply();
        refresh(false);
    }

    private void refresh(boolean regenThumbs) {
        boolean video = Scenes.isVideo(selected);
        Palette p = draft.palette();

        sceneTitle.setText(Scenes.title(selected));
        sceneSub.setText(Scenes.subtitle(selected));
        paletteName.setText(p.name);
        for (PaletteChip ch : chips) ch.setChosen(ch.palette == p);
        for (String id : Scenes.IDS) {
            GradientDrawable bd = cardBorders.get(id);
            if (bd == null) continue;
            boolean on = id.equals(selected);
            bd.setStroke(on ? dp(2) : dp(1), on ? p.a : LINE);
        }
        for (int i = 0; i < overlayChips.size(); i++) {
            boolean on = OVERLAYS[i].equals(draft.overlay);
            TextView t = overlayChips.get(i);
            t.setBackground(stroke(on ? U.alpha(p.a, 46) : SURFACE, on ? p.a : LINE, dp(1), dp(100)));
            t.setTextColor(on ? TEXT : MUTED);
        }

        paletteSection.setVisibility(video ? View.GONE : View.VISIBLE);
        tuneSection.setVisibility(video ? View.GONE : View.VISIBLE);
        photoSection.setVisibility("photo".equals(selected) ? View.VISIBLE : View.GONE);
        videoSection.setVisibility(video ? View.VISIBLE : View.GONE);
        pickPhotoBtn.setText(hasFile(draft.photoPath) ? "Заменить фото" : "Выбрать фото");
        pickVideoBtn.setText(hasFile(draft.videoPath) ? "Заменить видео" : "Выбрать видео");

        applyAccent(p, video && !hasFile(draft.videoPath));
        updateLabels();
        bindPreview();
        if (regenThumbs) renderThumbs();
    }

    private void bindPreview() {
        if (Scenes.isVideo(selected)) {
            preview.setRunning(false);
            preview.setVisibility(View.GONE);
            videoPreview.setVisibility(View.VISIBLE);
            videoPreview.setVideo(draft.videoPath);
            videoHint.setVisibility(hasFile(draft.videoPath) ? View.GONE : View.VISIBLE);
        } else {
            videoPreview.stop();
            videoPreview.setVisibility(View.GONE);
            videoHint.setVisibility(View.GONE);
            preview.setVisibility(View.VISIBLE);
            preview.bind(selected, draft);
            preview.setRunning(true);
        }
    }

    private void applyAccent(Palette p, boolean disabled) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{p.a, p.b});
        g.setCornerRadius(dp(18));
        applyBtn.setBackground(new RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), g, null));
        applyBtn.setAlpha(disabled ? 0.45f : 1f);
        applyBtn.setText(disabled ? "Сначала выберите видео" : "Установить обои");

        ColorStateList acc = ColorStateList.valueOf(p.a);
        ColorStateList line = ColorStateList.valueOf(LINE);
        for (SeekBar s : new SeekBar[]{speedBar, densityBar, brightBar}) {
            s.setProgressTintList(acc);
            s.setThumbTintList(acc);
            s.setProgressBackgroundTintList(line);
        }
        int[][] states = {{android.R.attr.state_checked}, {}};
        ColorStateList thumb = new ColorStateList(states, new int[]{p.a, 0xFFBDB4D8});
        ColorStateList track = new ColorStateList(states, new int[]{U.alpha(p.a, 110), LINE});
        for (Switch s : new Switch[]{fpsSw, touchSw, parallaxSw}) {
            s.setThumbTintList(thumb);
            s.setTrackTintList(track);
        }
    }

    /** Переносит значения настроек в элементы управления (без обратной записи). */
    private void syncControls() {
        speedBar.setProgress(Math.round((draft.speed - 0.2f) / 2.3f * 100f));
        densityBar.setProgress(Math.round((draft.density - 0.4f) / 1.6f * 100f));
        brightBar.setProgress(Math.round((draft.brightness - 0.35f) / 0.65f * 100f));
        fpsSw.setChecked(draft.fps >= 60);
        touchSw.setChecked(draft.touch);
        parallaxSw.setChecked(draft.parallax);
    }

    private void updateLabels() {
        speedVal.setText(String.format(Locale.US, "×%.1f", draft.speed));
        densityVal.setText(String.format(Locale.US, "×%.1f", draft.density));
        brightVal.setText(Math.round(draft.brightness * 100f) + "%");
    }

    private void renderThumbs() {
        final int gen = ++thumbGen;
        final WallConfig snap = draft.copy();
        final int tw = dp(92), th = dp(164);
        new Thread(() -> {
            for (String id : Scenes.IDS) {
                if (gen != thumbGen) return;
                final Bitmap b = Media.thumb(id, snap, tw, th);
                runOnUiThread(() -> {
                    if (gen != thumbGen || b == null) return;
                    ImageView iv = thumbs.get(id);
                    if (iv != null) iv.setImageBitmap(b);
                });
            }
        }, "thumbs").start();
    }

    // ------------------------------------------------------------------ действия

    private void apply() {
        boolean video = Scenes.isVideo(selected);
        if (video && !hasFile(draft.videoPath)) {
            toast("Сначала выберите видео");
            return;
        }
        if (!video) draft.scene = selected;
        draft.save(this);
        Media.cleanup(this, draft.photoPath, draft.videoPath);

        ComponentName target = new ComponentName(this,
                video ? VideoWallpaperService.class : NeonWallpaperService.class);
        if (isActive(target)) {
            toast("Обои обновлены");
            return;
        }
        Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
        i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, target);
        try {
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
                toast("Выберите «Neon Drift» в списке");
            } catch (Exception e2) {
                toast("Не удалось открыть выбор обоев");
            }
        }
    }

    private boolean isActive(ComponentName target) {
        try {
            WallpaperInfo info = WallpaperManager.getInstance(this).getWallpaperInfo();
            return info != null && target.equals(info.getComponent());
        } catch (Exception e) {
            return false;
        }
    }

    private void pick(String mime, int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        try {
            startActivityForResult(i, req);
        } catch (Exception e) {
            Intent g = new Intent(Intent.ACTION_GET_CONTENT);
            g.setType(mime);
            try {
                startActivityForResult(Intent.createChooser(g, null), req);
            } catch (Exception e2) {
                toast("Нет приложения для выбора файлов");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        if (requestCode != REQ_PHOTO && requestCode != REQ_VIDEO) return;
        final Uri uri = data.getData();
        final boolean photo = requestCode == REQ_PHOTO;
        toast(photo ? "Загружаю фото…" : "Копирую видео…");
        new Thread(() -> {
            final String path = photo
                    ? Media.importPhoto(getApplicationContext(), uri)
                    : Media.importVideo(getApplicationContext(), uri);
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (path == null) {
                    toast(photo ? "Не удалось открыть фото" : "Не удалось открыть видео");
                    return;
                }
                if (photo) draft.photoPath = path;
                else draft.videoPath = path;
                refresh(true);
            });
        }, "import").start();
    }

    // ------------------------------------------------------------------ помощники

    private static boolean known(String id) {
        if (id == null) return false;
        for (String s : Scenes.IDS) if (s.equals(id)) return true;
        return false;
    }

    private static boolean hasFile(String path) {
        return path != null && new File(path).exists();
    }

    private int dp(float v) {
        return Math.round(v * dens);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private static LinearLayout.LayoutParams margins(int w, int h, int left, int top) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(w, h);
        l.leftMargin = left;
        l.topMargin = top;
        return l;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 11, MUTED, true);
        t.setLetterSpacing(0.18f);
        return t;
    }

    private TextView valueText() {
        TextView t = text("", 13, TEXT, true);
        t.setGravity(Gravity.END);
        return t;
    }

    private TextView secondaryButton(String s, View.OnClickListener l) {
        TextView b = text(s, 15, TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(16), dp(14), dp(16), dp(14));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22FFFFFF),
                stroke(SURFACE, LINE, dp(1), dp(16)), null));
        b.setOnClickListener(l);
        return b;
    }

    private void addSlider(LinearLayout parent, String name, SeekBar bar, TextView val) {
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        TextView t = text(name, 15, TEXT, false);
        head.addView(t, new LinearLayout.LayoutParams(0, WRAP, 1f));
        head.addView(val, new LinearLayout.LayoutParams(WRAP, WRAP));
        parent.addView(head, margins(MATCH, WRAP, 0, dp(14)));
        bar.setMax(100);
        bar.setPadding(0, dp(10), 0, dp(10));
        parent.addView(bar, margins(MATCH, WRAP, 0, dp(2)));
    }

    private Switch switchRow(LinearLayout parent, String title, String sub) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout texts = vertical();
        texts.addView(text(title, 15, TEXT, false));
        if (sub != null) texts.addView(text(sub, 12, MUTED, false), margins(MATCH, WRAP, 0, dp(2)));
        row.addView(texts, new LinearLayout.LayoutParams(0, WRAP, 1f));
        Switch sw = new Switch(this);
        row.addView(sw, margins(WRAP, WRAP, dp(12), 0));
        parent.addView(row, margins(MATCH, WRAP, 0, dp(16)));
        return sw;
    }

    private static GradientDrawable fill(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private static GradientDrawable stroke(int fillColor, int strokeColor, int width, float radius) {
        GradientDrawable g = fill(fillColor, radius);
        g.setStroke(width, strokeColor);
        return g;
    }

    private static ViewOutlineProvider rounded(final float r) {
        return new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), r);
            }
        };
    }

    private abstract static class Seek implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onProgressChanged(SeekBar s, int p, boolean user) {
        }

        @Override
        public void onStartTrackingTouch(SeekBar s) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar s) {
        }
    }
}
