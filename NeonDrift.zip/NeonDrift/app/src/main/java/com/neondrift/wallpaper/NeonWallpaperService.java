package com.neondrift.wallpaper;

import android.app.WallpaperColors;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.view.Choreographer;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

/** Живые обои с анимированными сценами. Рисует только когда экран виден. */
public class NeonWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new NeonEngine();
    }

    final class NeonEngine extends Engine implements Choreographer.FrameCallback,
            SharedPreferences.OnSharedPreferenceChangeListener {

        private final Handler main = new Handler(Looper.getMainLooper());
        private final Choreographer choreographer = Choreographer.getInstance();
        private final Runnable reload = this::reloadConfig;

        private SharedPreferences prefs;
        private PowerManager power;
        private WallConfig cfg = new WallConfig();
        private Scene scene;

        private boolean visible, surfaceOk, scheduled, useHw = true;
        private int width, height;
        private long lastDraw, nextDue, lastRawTouch;
        private float lastOffset = 0.5f;

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            Context ctx = NeonWallpaperService.this;
            prefs = WallConfig.prefs(ctx);
            prefs.registerOnSharedPreferenceChangeListener(this);
            power = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            cfg = WallConfig.load(ctx);
            setTouchEventsEnabled(true);
            setOffsetNotificationsEnabled(true);
        }

        @Override
        public void onDestroy() {
            if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(this);
            main.removeCallbacks(reload);
            stopFrames();
            if (scene != null) {
                scene.release();
                scene = null;
            }
            super.onDestroy();
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            super.onSurfaceChanged(holder, format, w, h);
            width = w;
            height = h;
            surfaceOk = true;
            buildScene();
            requestFrame();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            surfaceOk = false;
            stopFrames();
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onVisibilityChanged(boolean v) {
            visible = v;
            if (v) {
                lastDraw = 0;
                nextDue = 0;
                requestFrame();
            } else {
                stopFrames();
            }
        }

        @Override
        public void onOffsetsChanged(float xOffset, float yOffset, float xStep, float yStep, int xPixels, int yPixels) {
            lastOffset = xOffset;
            if (scene != null) scene.setOffset(xOffset);
        }

        @Override
        public void onTouchEvent(MotionEvent event) {
            if (scene == null) return;
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) lastRawTouch = SystemClock.uptimeMillis();
            scene.touch(event.getX(), event.getY(), action);
            requestFrame();
        }

        @Override
        public Bundle onCommand(String action, int x, int y, int z, Bundle extras, boolean resultRequested) {
            if (WallpaperManager.COMMAND_TAP.equals(action) && scene != null
                    && SystemClock.uptimeMillis() - lastRawTouch > 400) {
                scene.touch(x, y, Scene.TAP);
                requestFrame();
            }
            return null;
        }

        @Override
        public WallpaperColors onComputeColors() {
            if (Build.VERSION.SDK_INT < 27) return null;
            Palette p = cfg.palette();
            return new WallpaperColors(Color.valueOf(p.a), Color.valueOf(p.b), Color.valueOf(p.bgBottom));
        }

        @Override
        public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
            main.removeCallbacks(reload);
            main.postDelayed(reload, 150);
        }

        private void reloadConfig() {
            cfg = WallConfig.load(NeonWallpaperService.this);
            if (surfaceOk) buildScene();
            if (Build.VERSION.SDK_INT >= 27) notifyColorsChanged();
            requestFrame();
        }

        private void buildScene() {
            if (scene != null) scene.release();
            String id = Scenes.isVideo(cfg.scene) ? "city" : cfg.scene;
            scene = Scenes.create(id);
            scene.setup(width, height, cfg);
            scene.setOffset(lastOffset);
        }

        private void requestFrame() {
            if (!scheduled && visible && surfaceOk) {
                scheduled = true;
                choreographer.postFrameCallback(this);
            }
        }

        private void stopFrames() {
            if (scheduled) {
                choreographer.removeFrameCallback(this);
                scheduled = false;
            }
        }

        @Override
        public void doFrame(long now) {
            scheduled = false;
            if (!visible || !surfaceOk || scene == null) return;

            int fps = cfg.fps >= 60 ? 60 : 30;
            if (power != null && power.isPowerSaveMode()) fps = 30;
            long gap = 1_000_000_000L / fps;

            if (nextDue != 0 && now + 2_000_000L < nextDue) {
                requestFrame();
                return;
            }
            nextDue = (nextDue == 0 || now - nextDue > gap) ? now + gap : nextDue + gap;

            float dt = lastDraw == 0 ? 1f / fps : (now - lastDraw) / 1e9f;
            lastDraw = now;
            if (dt > 0.1f) dt = 0.1f;

            scene.step(dt);
            drawFrame();
            requestFrame();
        }

        private void drawFrame() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                if (useHw) {
                    try {
                        c = holder.lockHardwareCanvas();
                    } catch (Throwable t) {
                        useHw = false;
                        c = null;
                    }
                }
                if (c == null) c = holder.lockCanvas();
                if (c == null) return;
                scene.render(c);
            } catch (Throwable ignored) {
                // один пропущенный кадр лучше, чем упавшие обои
            } finally {
                if (c != null) {
                    try {
                        holder.unlockCanvasAndPost(c);
                    } catch (Throwable ignored) {
                    }
                }
            }
        }
    }
}
