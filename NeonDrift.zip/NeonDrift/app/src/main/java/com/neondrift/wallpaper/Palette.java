package com.neondrift.wallpaper;

import android.graphics.Color;

/** Цветовая схема: два цвета фона и три неоновых. */
final class Palette {
    final String name;
    final int bgTop, bgBottom, a, b, c;

    private Palette(String name, String bgTop, String bgBottom, String a, String b, String c) {
        this.name = name;
        this.bgTop = Color.parseColor(bgTop);
        this.bgBottom = Color.parseColor(bgBottom);
        this.a = Color.parseColor(a);
        this.b = Color.parseColor(b);
        this.c = Color.parseColor(c);
    }

    static final Palette[] ALL = {
            new Palette("Киберпанк", "#0A0618", "#1C0733", "#FF2D95", "#00E5FF", "#FFC24D"),
            new Palette("Закат", "#14051F", "#3A0B3D", "#FF6A3D", "#FF2E88", "#FFD36E"),
            new Palette("Океан", "#020B1A", "#06304A", "#00D1C1", "#2E7DFF", "#A7F3FF"),
            new Palette("Токсик", "#040C06", "#0B2612", "#7CFF6B", "#00FFA3", "#E9FF70"),
            new Palette("Ультрафиолет", "#0A0420", "#1E0B4D", "#8B5CFF", "#FF4FD8", "#6EE7FF"),
            new Palette("Огонь", "#120403", "#2E0A04", "#FF4D1F", "#FFB020", "#FFE08A"),
            new Palette("Лёд", "#050812", "#14223D", "#9FD8FF", "#5C8DFF", "#F0FAFF"),
            new Palette("Моно", "#050505", "#161616", "#FFFFFF", "#8A8A8A", "#D9D9D9"),
    };

    static Palette get(int i) {
        int n = ALL.length;
        return ALL[((i % n) + n) % n];
    }
}
