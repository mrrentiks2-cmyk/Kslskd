package com.neondrift.wallpaper;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import java.io.File;

/** Своё фото: медленный наезд камеры, параллакс и эффект поверх снимка. */
final class PhotoScene extends Scene {
    private static final int BURST = 30;

    private Bitmap photo;
    private float baseScale;
    private final Matrix m = new Matrix();
    private final Paint bmp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint vignette = new Paint(), bg = new Paint();
    private final Paint fx = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG);

    private String overlay;
    private int n;
    private float[] px, py, pr, pv, pph;
    private int[] pc;
    private Bitmap[] glows;
    private Bitmap soft;

    private final float[] bx = new float[BURST], by = new float[BURST], bvx = new float[BURST],
            bvy = new float[BURST], bl = new float[BURST];
    private final int[] bc = new int[BURST];

    @Override
    protected void onSetup() {
        photo = load(cfg.photoPath, w, h);
        if (photo != null) {
            baseScale = Math.max(w * 1.12f / photo.getWidth(), h * 1.06f / photo.getHeight());
        }
        vignette.setShader(new RadialGradient(w / 2f, h * 0.45f, Math.max(w, h) * 0.75f,
                new int[]{0x00000000, 0x00000000, 0x99000000}, new float[]{0f, 0.55f, 1f},
                Shader.TileMode.CLAMP));
        bg.setShader(U.vgrad(0, h, new int[]{pal.bgTop, pal.bgBottom}, null));
        txt.setColor(U.alpha(U.WHITE, 200));
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTextSize(18f * scale);

        glows = new Bitmap[]{U.glow(pal.a, true), U.glow(pal.b, true), U.glow(pal.c, true)};
        soft = U.glow(U.WHITE, false);

        overlay = cfg.overlay == null ? "none" : cfg.overlay;
        float k = Math.max(0.5f, areaK()) * cfg.density;
        switch (overlay) {
            case "snow": n = Math.round(90 * k + 20); break;
            case "sparks": n = Math.round(26 * cfg.density + 6); break;
            case "bubbles": n = Math.round(20 * cfg.density + 6); break;
            case "rain": n = Math.round(120 * k + 30); break;
            default: n = 0;
        }
        px = new float[n];
        py = new float[n];
        pr = new float[n];
        pv = new float[n];
        pph = new float[n];
        pc = new int[n];
        for (int i = 0; i < n; i++) spawn(i, true);
        for (int i = 0; i < BURST; i++) bl[i] = 0f;
        fx.setStrokeCap(Paint.Cap.ROUND);
    }

    static Bitmap load(String path, int w, int h) {
        if (path == null || !new File(path).exists()) return null;
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, o);
            if (o.outWidth <= 0 || o.outHeight <= 0) return null;
            int sample = 1;
            float tw = w * 1.15f, th = h * 1.1f;
            while (o.outWidth / (sample * 2) >= tw && o.outHeight / (sample * 2) >= th) sample *= 2;
            while (Math.max(o.outWidth, o.outHeight) / sample > 4096) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            return BitmapFactory.decodeFile(path, o2);
        } catch (Throwable t) {
            return null;
        }
    }

    private void spawn(int i, boolean initial) {
        px[i] = U.rand(0, w);
        pph[i] = U.rand(0, U.TAU);
        pc[i] = U.R.nextInt(3);
        switch (overlay) {
            case "snow":
                pr[i] = U.rand(1.2f, 4.2f) * scale;
                pv[i] = U.rand(25f, 80f) * scale * (pr[i] / (3f * scale));
                py[i] = initial ? U.rand(0, h) : -pr[i] * 3f;
                break;
            case "sparks":
                pr[i] = U.rand(5f, 14f) * scale;
                pv[i] = U.rand(0.6f, 1.4f);
                py[i] = U.rand(0, h);
                pph[i] = initial ? U.rand(0, U.TAU) : 0f;
                break;
            case "bubbles":
                pr[i] = U.rand(5f, 18f) * scale;
                pv[i] = U.rand(25f, 60f) * scale;
                py[i] = initial ? U.rand(0, h) : h + pr[i] * 2f;
                break;
            case "rain":
                pr[i] = U.rand(18f, 50f) * scale;
                pv[i] = U.rand(700f, 1100f) * scale;
                py[i] = initial ? U.rand(0, h) : -pr[i];
                break;
            default:
                break;
        }
    }

    @Override
    protected void update(float dt, float realDt) {
        for (int i = 0; i < n; i++) {
            switch (overlay) {
                case "snow":
                    py[i] += pv[i] * dt;
                    px[i] += U.sin(time * 0.8f + pph[i]) * 14f * scale * dt;
                    if (py[i] > h + pr[i] * 3f) spawn(i, false);
                    break;
                case "sparks":
                    pph[i] += dt * pv[i] * 2f;
                    if (pph[i] > U.TAU) spawn(i, false);
                    break;
                case "bubbles":
                    py[i] -= pv[i] * dt;
                    px[i] += U.sin(time * 1.3f + pph[i]) * 10f * scale * dt;
                    if (py[i] < -pr[i] * 2f) spawn(i, false);
                    break;
                case "rain":
                    py[i] += pv[i] * dt;
                    px[i] -= pv[i] * 0.18f * dt;
                    if (py[i] > h + pr[i]) {
                        spawn(i, false);
                        px[i] = U.rand(0, w * 1.2f);
                    }
                    break;
                default:
                    break;
            }
        }
        float decay = (float) Math.exp(-2.0 * realDt);
        for (int i = 0; i < BURST; i++) {
            if (bl[i] <= 0f) continue;
            bx[i] += bvx[i] * realDt;
            by[i] += bvy[i] * realDt;
            bvx[i] *= decay;
            bvy[i] *= decay;
            bl[i] -= realDt;
        }
    }

    @Override
    protected void draw(Canvas c) {
        if (photo == null) {
            c.drawRect(0, 0, w, h, bg);
            c.drawText("Выберите фото", w / 2f, h / 2f - 12f * scale, txt);
            c.drawText("в приложении", w / 2f, h / 2f + 14f * scale, txt);
            drawBursts(c);
            return;
        }
        float zoom = 1f + 0.04f * (0.5f - 0.5f * U.cos(time * 0.22f));
        float s = baseScale * zoom;
        float dw = photo.getWidth() * s, dh = photo.getHeight() * s;
        m.setScale(s, s);
        m.postTranslate((w - dw) / 2f - par() * w * 0.05f, (h - dh) / 2f);
        c.drawBitmap(photo, m, bmp);

        for (int i = 0; i < n; i++) {
            switch (overlay) {
                case "snow": {
                    int a = Math.round(150 + 90 * (pr[i] / (4.2f * scale)));
                    if (pr[i] > 3f * scale) {
                        sprite(c, soft, px[i], py[i], pr[i] * 2.4f, a);
                    } else {
                        fx.setColor(U.alpha(U.WHITE, a));
                        c.drawCircle(px[i], py[i], pr[i], fx);
                    }
                    break;
                }
                case "sparks": {
                    float tw = Math.max(0f, U.sin(pph[i] * 0.5f));
                    sprite(c, glows[pc[i]], px[i], py[i], pr[i] * (0.6f + 0.4f * tw), Math.round(255 * tw));
                    break;
                }
                case "bubbles": {
                    fx.setStyle(Paint.Style.STROKE);
                    fx.setStrokeWidth(1.3f * scale);
                    fx.setColor(U.alpha(U.WHITE, 120));
                    c.drawCircle(px[i], py[i], pr[i], fx);
                    fx.setStyle(Paint.Style.FILL);
                    fx.setColor(U.alpha(U.WHITE, 150));
                    c.drawCircle(px[i] - pr[i] * 0.35f, py[i] - pr[i] * 0.35f, pr[i] * 0.18f, fx);
                    break;
                }
                case "rain": {
                    fx.setStyle(Paint.Style.FILL);
                    fx.setStrokeWidth(1.4f * scale);
                    fx.setColor(U.alpha(U.mix(U.WHITE, pal.b, 0.3f), 110));
                    c.drawLine(px[i], py[i], px[i] + pr[i] * 0.18f, py[i] - pr[i], fx);
                    break;
                }
                default:
                    break;
            }
        }
        c.drawRect(0, 0, w, h, vignette);
        drawBursts(c);
    }

    private void drawBursts(Canvas c) {
        for (int i = 0; i < BURST; i++) {
            if (bl[i] <= 0f) continue;
            float k = Math.min(1f, bl[i] / 1.1f);
            sprite(c, glows[bc[i]], bx[i], by[i], 9f * scale * (0.5f + 0.5f * k), Math.round(255 * k));
        }
    }

    @Override
    protected void onTouch(float tx, float ty, int action) {
        if (!isPress(action)) return;
        int spawned = 0;
        for (int i = 0; i < BURST && spawned < 12; i++) {
            if (bl[i] > 0f) continue;
            float a = U.rand(0, U.TAU), s = U.rand(80f, 260f) * scale;
            bx[i] = tx;
            by[i] = ty;
            bvx[i] = U.cos(a) * s;
            bvy[i] = U.sin(a) * s;
            bl[i] = U.rand(0.8f, 1.3f);
            bc[i] = U.R.nextInt(3);
            spawned++;
        }
    }

    @Override
    void release() {
        photo = null;
    }
}
