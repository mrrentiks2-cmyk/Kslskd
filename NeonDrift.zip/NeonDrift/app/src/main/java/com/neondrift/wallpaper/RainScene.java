package com.neondrift.wallpaper;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;

/** Цифровой дождь: колонки символов с яркой «головой» и угасающим хвостом. */
final class RainScene extends Scene {
    private static final char[] GL =
            "0123456789АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЩЭЮЯ<>/\\|=+*#%$&@".toCharArray();

    private int cols, rows;
    private float cell;
    private float[] head, spd, mut;
    private int[] len, lastRow;
    private char[][] g;
    private int[] trail;
    private int headColor;
    private Bitmap headGlow, field;
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG), bg = new Paint();
    private final Paint bmp = new Paint(Paint.FILTER_BITMAP_FLAG);

    @Override
    protected void onSetup() {
        cell = w / (18f * cfg.density + 10f);
        cols = (int) Math.ceil(w / cell) + 2;
        rows = (int) Math.ceil(h / cell) + 1;
        g = new char[cols][rows];
        for (int i = 0; i < cols; i++)
            for (int j = 0; j < rows; j++) g[i][j] = GL[U.R.nextInt(GL.length)];
        head = new float[cols];
        spd = new float[cols];
        mut = new float[cols];
        len = new int[cols];
        lastRow = new int[cols];
        for (int i = 0; i < cols; i++) reset(i, true);

        tp.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        tp.setTextSize(cell * 0.9f);
        tp.setTextAlign(Paint.Align.CENTER);

        // тусклое поле символов под потоками — рисуется один раз
        field = Bitmap.createBitmap(Math.round(cols * cell), h, Bitmap.Config.ARGB_8888);
        Canvas fc = new Canvas(field);
        Paint fp = new Paint(Paint.ANTI_ALIAS_FLAG);
        fp.setTypeface(tp.getTypeface());
        fp.setTextSize(cell * 0.9f);
        fp.setTextAlign(Paint.Align.CENTER);
        fp.setColor(U.alpha(pal.b, 26));
        for (int i = 0; i < cols; i++)
            for (int j = 0; j < rows; j++)
                if (U.R.nextFloat() < 0.55f) fc.drawText(g[i], j, 1, (i + 0.5f) * cell, j * cell + cell * 0.82f, fp);
        bg.setShader(U.vgrad(0, h, new int[]{pal.bgTop, pal.bgBottom, pal.bgTop}, new float[]{0f, 0.65f, 1f}));
        trail = new int[32];
        for (int k = 0; k < 32; k++) trail[k] = U.mix(pal.a, pal.b, k / 31f);
        headColor = U.mix(pal.c, U.WHITE, 0.55f);
        headGlow = U.glow(pal.c, false);
    }

    private void reset(int i, boolean initial) {
        len[i] = 12 + U.R.nextInt(26);
        spd[i] = U.rand(5f, 14f);
        head[i] = initial ? U.rand(0f, rows + len[i]) : -U.rand(0f, rows * 0.15f);
        mut[i] = U.rand(0.05f, 0.3f);
        lastRow[i] = (int) head[i];
    }

    @Override
    protected void update(float dt, float realDt) {
        for (int i = 0; i < cols; i++) {
            head[i] += spd[i] * dt;
            if (head[i] - len[i] > rows) reset(i, false);
            int hr = (int) head[i];
            if (hr != lastRow[i]) {
                lastRow[i] = hr;
                if (hr >= 0 && hr < rows) g[i][hr] = GL[U.R.nextInt(GL.length)];
            }
            mut[i] -= dt;
            if (mut[i] <= 0f) {
                g[i][U.R.nextInt(rows)] = GL[U.R.nextInt(GL.length)];
                mut[i] = U.rand(0.04f, 0.25f);
            }
        }
    }

    @Override
    protected void draw(Canvas c) {
        c.drawRect(0, 0, w, h, bg);
        float shift = -par() * cell * 1.5f - cell;
        float baseline = cell * 0.82f;
        c.drawBitmap(field, shift, 0, bmp);
        for (int i = 0; i < cols; i++) {
            float x = (i + 0.5f) * cell + shift;
            int hr = (int) head[i];
            int L = len[i];
            for (int k = 0; k < L; k++) {
                int row = hr - k;
                if (row < 0) break;
                if (row >= rows) continue;
                if (k == 0) {
                    tp.setColor(headColor);
                } else {
                    float t = k / (float) L;
                    int a = Math.round(255f * (float) Math.pow(1f - t, 1.2));
                    tp.setColor(U.alpha(trail[Math.min(31, (int) (t * 31f))], a));
                }
                c.drawText(g[i], row, 1, x, row * cell + baseline, tp);
            }
            if (hr >= 0 && hr < rows) sprite(c, headGlow, x, hr * cell + cell * 0.5f, cell * 1.4f, 120);
        }
    }

    @Override
    protected void onTouch(float x, float y, int action) {
        if (!isPress(action)) return;
        float shift = -par() * cell * 1.5f - cell;
        int center = (int) ((x - shift) / cell);
        int r = 3 + Math.round(2 * cfg.density);
        for (int i = center - r; i <= center + r; i++) {
            if (i < 0 || i >= cols) continue;
            head[i] = y / cell + U.rand(-1.5f, 1.5f);
            spd[i] = U.rand(12f, 20f);
            len[i] = 10 + U.R.nextInt(16);
        }
    }
}
