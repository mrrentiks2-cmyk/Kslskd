package com.neondrift.wallpaper;

import android.graphics.Canvas;
import android.graphics.Paint;

/** Расходящиеся кольца от касаний — общие для всех сцен. */
final class Ripples {
    private static final int MAX = 8;
    private static final float LIFE = 1.1f;

    private final float[] xs = new float[MAX], ys = new float[MAX], ts = new float[MAX];
    private final boolean[] on = new boolean[MAX];
    private int next;
    private float scale = 1f;
    private int c1, c2;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    void setup(Palette pal, float scale) {
        this.scale = scale;
        c1 = pal.b;
        c2 = pal.a;
        p.setStyle(Paint.Style.STROKE);
        for (int i = 0; i < MAX; i++) on[i] = false;
    }

    void add(float x, float y) {
        int i = next;
        next = (next + 1) % MAX;
        xs[i] = x;
        ys[i] = y;
        ts[i] = 0f;
        on[i] = true;
    }

    void update(float dt) {
        for (int i = 0; i < MAX; i++) {
            if (!on[i]) continue;
            ts[i] += dt;
            if (ts[i] > LIFE) on[i] = false;
        }
    }

    void draw(Canvas c) {
        for (int i = 0; i < MAX; i++) {
            if (!on[i]) continue;
            float k = ts[i] / LIFE;
            float e = 1f - (1f - k) * (1f - k);
            float r = (14f + 150f * e) * scale;
            int a = Math.round(230f * (1f - k));
            p.setStrokeWidth((1f + 4f * (1f - k)) * scale);
            p.setColor(U.alpha(c1, a));
            c.drawCircle(xs[i], ys[i], r, p);
            p.setStrokeWidth((1f + 2f * (1f - k)) * scale);
            p.setColor(U.alpha(c2, a / 2));
            c.drawCircle(xs[i], ys[i], r * 0.62f, p);
        }
    }
}
