package com.neondrift.wallpaper;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;

/**
 * Базовая сцена. Одна и та же сцена рисует и настоящие обои, и превью в приложении,
 * и миниатюры — поэтому всё считается от размеров холста.
 */
abstract class Scene {
    /** Тап, пришедший от лаунчера (без отпускания пальца). */
    static final int TAP = 1000;

    protected int w, h;
    protected WallConfig cfg;
    protected Palette pal;
    /** Масштаб «единицы»: 1 на экране шириной 400 px. */
    protected float scale = 1f;
    /** Время сцены в секундах с учётом скорости. */
    protected float time;

    private float offset = 0.5f, offsetTarget = 0.5f;
    private final Ripples ripples = new Ripples();
    private final Paint dim = new Paint();

    protected final RectF tmp = new RectF();
    protected final Paint sprite = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);

    final void setup(int width, int height, WallConfig config) {
        w = Math.max(1, width);
        h = Math.max(1, height);
        cfg = config;
        pal = config.palette();
        scale = Math.min(w, h) / 400f;
        time = 0f;
        ripples.setup(pal, scale);
        onSetup();
    }

    final void step(float dt) {
        float sdt = dt * cfg.speed;
        time += sdt;
        offset += (offsetTarget - offset) * Math.min(1f, dt * 6f);
        update(sdt, dt);
        ripples.update(dt);
    }

    final void render(Canvas c) {
        draw(c);
        ripples.draw(c);
        if (cfg.brightness < 0.995f) {
            dim.setColor(Color.argb(Math.round((1f - cfg.brightness) * 255f), 0, 0, 0));
            c.drawPaint(dim);
        }
    }

    final void touch(float x, float y, int action) {
        if (!cfg.touch) return;
        if (action == MotionEvent.ACTION_DOWN || action == TAP) ripples.add(x, y);
        onTouch(x, y, action);
    }

    /** Смещение рабочего стола 0..1 от лаунчера. */
    final void setOffset(float x) {
        offsetTarget = cfg.parallax ? U.clamp(x, 0f, 1f) : 0.5f;
    }

    /** Параллакс -1..1. */
    protected final float par() {
        return (offset - 0.5f) * 2f;
    }

    protected final boolean isPress(int action) {
        return action == MotionEvent.ACTION_DOWN || action == TAP;
    }

    protected final void sprite(Canvas c, Bitmap b, float x, float y, float radius, int alpha) {
        if (alpha <= 0) return;
        tmp.set(x - radius, y - radius, x + radius, y + radius);
        sprite.setAlpha(U.clamp(alpha, 0, 255));
        c.drawBitmap(b, null, tmp, sprite);
    }

    /** Площадь холста относительно типичного телефона, под корень — для числа частиц. */
    protected final float areaK() {
        return (float) Math.sqrt((w * (double) h) / (1080.0 * 2340.0));
    }

    protected abstract void onSetup();

    /** dt — время с учётом скорости, realDt — реальное. */
    protected abstract void update(float dt, float realDt);

    protected abstract void draw(Canvas c);

    protected void onTouch(float x, float y, int action) {}

    void release() {}
}
