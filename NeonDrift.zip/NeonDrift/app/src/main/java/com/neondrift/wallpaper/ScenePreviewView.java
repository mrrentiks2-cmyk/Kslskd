package com.neondrift.wallpaper;

import android.content.Context;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;

/** Живое превью сцены внутри приложения — тот же код, что и на рабочем столе. */
final class ScenePreviewView extends View {
    private Scene scene;
    private WallConfig cfg;
    private long last;
    private boolean running = true;

    ScenePreviewView(Context c) {
        super(c);
    }

    void bind(String id, WallConfig config) {
        if (scene != null) scene.release();
        cfg = config;
        scene = Scenes.create(id);
        if (getWidth() > 0 && getHeight() > 0) scene.setup(getWidth(), getHeight(), cfg);
        last = 0;
        invalidate();
    }

    /** Пересобрать сцену после изменения палитры или плотности. */
    void rebuild() {
        if (scene != null && cfg != null && getWidth() > 0) {
            scene.release();
            scene.setup(getWidth(), getHeight(), cfg);
            invalidate();
        }
    }

    void setRunning(boolean r) {
        running = r;
        last = 0;
        if (r) invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (scene != null && cfg != null && w > 0 && h > 0) scene.setup(w, h, cfg);
    }

    @Override
    protected void onDraw(Canvas c) {
        if (scene == null || cfg == null || getWidth() == 0) return;
        long now = System.nanoTime();
        float dt = last == 0 ? 1f / 60f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        scene.step(dt);
        scene.render(c);
        if (running && isShown()) postInvalidateOnAnimation();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (scene != null) {
            scene.touch(e.getX(), e.getY(), e.getActionMasked());
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                getParent().requestDisallowInterceptTouchEvent(true);
            }
        }
        return true;
    }
}
