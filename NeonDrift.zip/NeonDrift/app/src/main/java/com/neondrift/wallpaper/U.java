package com.neondrift.wallpaper;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import java.util.HashMap;
import java.util.Random;

/** Мелкие помощники: математика, цвета, кэш светящихся спрайтов. */
final class U {
    private U() {}

    static final Random R = new Random();
    static final float TAU = (float) (Math.PI * 2.0);
    static final int WHITE = 0xFFFFFFFF;
    static final int BLACK = 0xFF000000;

    static float clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
    static int clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
    static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    static float rand(float a, float b) { return a + R.nextFloat() * (b - a); }
    static float fract(float v) { return v - (float) Math.floor(v); }
    static float sin(float v) { return (float) Math.sin(v); }
    static float cos(float v) { return (float) Math.cos(v); }

    /** Тот же цвет с альфой 0..255. */
    static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (clamp(a, 0, 255) << 24);
    }

    static int mix(int c1, int c2, float t) {
        t = clamp(t, 0f, 1f);
        int a = Math.round(lerp(Color.alpha(c1), Color.alpha(c2), t));
        int r = Math.round(lerp(Color.red(c1), Color.red(c2), t));
        int g = Math.round(lerp(Color.green(c1), Color.green(c2), t));
        int b = Math.round(lerp(Color.blue(c1), Color.blue(c2), t));
        return Color.argb(a, r, g, b);
    }

    static Shader vgrad(float y0, float y1, int[] colors, float[] stops) {
        return new LinearGradient(0, y0, 0, y1, colors, stops, Shader.TileMode.CLAMP);
    }

    static PorterDuffXfermode add() {
        return new PorterDuffXfermode(PorterDuff.Mode.ADD);
    }

    // ------------------------------------------------------------------ спрайты
    private static final HashMap<String, Bitmap> CACHE = new HashMap<>();
    private static final int SPRITE = 128;

    /** Мягкое свечение. core=true — с белой сердцевиной (звёзды, огни). */
    static synchronized Bitmap glow(int color, boolean core) {
        String key = (core ? "g" : "s") + Integer.toHexString(color);
        Bitmap b = CACHE.get(key);
        if (b != null) return b;
        int[] cols;
        float[] pos;
        if (core) {
            cols = new int[]{WHITE, alpha(color, 255), alpha(color, 70), alpha(color, 0)};
            pos = new float[]{0f, 0.16f, 0.42f, 1f};
        } else {
            cols = new int[]{alpha(color, 200), alpha(color, 95), alpha(color, 28), alpha(color, 0)};
            pos = new float[]{0f, 0.3f, 0.62f, 1f};
        }
        b = radial(cols, pos);
        CACHE.put(key, b);
        return b;
    }

    /** Диск боке: полупрозрачный центр и более яркий ободок. */
    static synchronized Bitmap bokeh(int color) {
        String key = "b" + Integer.toHexString(color);
        Bitmap b = CACHE.get(key);
        if (b != null) return b;
        b = radial(new int[]{alpha(color, 60), alpha(color, 80), alpha(color, 150), alpha(color, 60), alpha(color, 0)},
                new float[]{0f, 0.6f, 0.86f, 0.95f, 1f});
        CACHE.put(key, b);
        return b;
    }

    private static Bitmap radial(int[] cols, float[] pos) {
        Bitmap b = Bitmap.createBitmap(SPRITE, SPRITE, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float r = SPRITE / 2f;
        p.setShader(new RadialGradient(r, r, r, cols, pos, Shader.TileMode.CLAMP));
        c.drawCircle(r, r, r, p);
        return b;
    }
}
