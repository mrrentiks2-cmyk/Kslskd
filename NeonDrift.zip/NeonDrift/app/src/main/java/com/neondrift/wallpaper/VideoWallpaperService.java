package com.neondrift.wallpaper;

import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.io.File;

/**
 * Видео-обои. Отдельный сервис: поверхность отдаётся плееру целиком
 * и никогда не рисуется через Canvas, иначе плеер не сможет к ней подключиться.
 */
public class VideoWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new VideoEngine();
    }

    final class VideoEngine extends Engine implements SharedPreferences.OnSharedPreferenceChangeListener {
        private SharedPreferences prefs;
        private MediaPlayer player;
        private String playing;
        private boolean visible, prepared, surfaceOk;

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            prefs = WallConfig.prefs(VideoWallpaperService.this);
            prefs.registerOnSharedPreferenceChangeListener(this);
            setTouchEventsEnabled(false);
        }

        @Override
        public void onDestroy() {
            if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(this);
            releasePlayer();
            super.onDestroy();
        }

        @Override
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            surfaceOk = true;
            start();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            surfaceOk = false;
            releasePlayer();
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onVisibilityChanged(boolean v) {
            visible = v;
            if (player == null) {
                if (v) start();
                return;
            }
            if (!prepared) return;
            try {
                if (v) player.start();
                else player.pause();
            } catch (IllegalStateException ignored) {
            }
        }

        @Override
        public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
            if (!"videoPath".equals(key)) return;
            String path = sp.getString("videoPath", null);
            if (path != null && path.equals(playing)) return;
            releasePlayer();
            start();
        }

        private void start() {
            if (!surfaceOk || player != null) return;
            String path = prefs.getString("videoPath", null);
            if (path == null || !new File(path).exists()) return;
            try {
                MediaPlayer mp = new MediaPlayer();
                player = mp;
                playing = path;
                prepared = false;
                mp.setSurface(getSurfaceHolder().getSurface());
                mp.setDataSource(path);
                mp.setLooping(true);
                mp.setVolume(0f, 0f);
                mp.setOnPreparedListener(p -> {
                    if (p != player) return;
                    prepared = true;
                    try {
                        p.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);
                    } catch (Exception ignored) {
                    }
                    if (visible) p.start();
                });
                mp.setOnErrorListener((p, what, extra) -> {
                    if (p == player) releasePlayer();
                    else p.release();
                    return true;
                });
                mp.prepareAsync();
            } catch (Exception e) {
                releasePlayer();
            }
        }

        private void releasePlayer() {
            if (player != null) {
                try {
                    player.release();
                } catch (Exception ignored) {
                }
            }
            player = null;
            playing = null;
            prepared = false;
        }
    }
}
