package com.neondrift.wallpaper;

import android.content.Context;
import android.content.SharedPreferences;

/** Все настройки обоев. Хранятся в SharedPreferences, общие для приложения и сервиса. */
final class WallConfig {
    static final String PREFS = "neon_wall";

    String scene = "city";
    int paletteIndex = 0;
    float speed = 1f;       // 0.2 .. 2.5
    float density = 1f;     // 0.4 .. 2.0
    float brightness = 1f;  // 0.35 .. 1.0
    int fps = 60;           // 30 или 60
    boolean touch = true;
    boolean parallax = true;
    String overlay = "sparks"; // none / snow / sparks / bubbles / rain
    String photoPath;
    String videoPath;

    Palette palette() { return Palette.get(paletteIndex); }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static WallConfig load(Context ctx) {
        SharedPreferences p = prefs(ctx);
        WallConfig w = new WallConfig();
        w.scene = p.getString("scene", w.scene);
        w.paletteIndex = p.getInt("palette", w.paletteIndex);
        w.speed = p.getFloat("speed", w.speed);
        w.density = p.getFloat("density", w.density);
        w.brightness = p.getFloat("brightness", w.brightness);
        w.fps = p.getInt("fps", w.fps);
        w.touch = p.getBoolean("touch", w.touch);
        w.parallax = p.getBoolean("parallax", w.parallax);
        w.overlay = p.getString("overlay", w.overlay);
        w.photoPath = p.getString("photoPath", null);
        w.videoPath = p.getString("videoPath", null);
        return w;
    }

    void save(Context ctx) {
        prefs(ctx).edit()
                .putString("scene", scene)
                .putInt("palette", paletteIndex)
                .putFloat("speed", speed)
                .putFloat("density", density)
                .putFloat("brightness", brightness)
                .putInt("fps", fps)
                .putBoolean("touch", touch)
                .putBoolean("parallax", parallax)
                .putString("overlay", overlay)
                .putString("photoPath", photoPath)
                .putString("videoPath", videoPath)
                .apply();
    }

    WallConfig copy() {
        WallConfig w = new WallConfig();
        w.scene = scene;
        w.paletteIndex = paletteIndex;
        w.speed = speed;
        w.density = density;
        w.brightness = brightness;
        w.fps = fps;
        w.touch = touch;
        w.parallax = parallax;
        w.overlay = overlay;
        w.photoPath = photoPath;
        w.videoPath = videoPath;
        return w;
    }
}
