package com.neondrift.wallpaper;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;

/** Гиперпрыжок: звёзды летят навстречу и растягиваются в штрихи. */
final class WarpScene extends Scene {
    private int n;
    private float[] sx, sy, sz;
    private int[] sc;
    private int[] cols;
    private float boost;
    private Bitmap core;
    private final Paint lp = new Paint(Paint.ANTI_ALIAS_FLAG), bg = new Paint();

    @Override
    protected void onSetup() {
        n = U.clamp(Math.round(260 * cfg.density * areaK() + 40), 60, 650);
        sx = new float[n];
        sy = new float[n];
        sz = new float[n];
        sc = new int[n];
        for (int i = 0; i < n; i++) respawn(i, true);
        cols = new int[]{pal.a, pal.b, pal.c, U.mix(U.WHITE, pal.b, 0.3f)};
        bg.setShader(new RadialGradient(w / 2f, h * 0.45f, Math.max(w, h) * 0.7f,
                new int[]{U.mix(pal.bgBottom, pal.a, 0.22f), pal.bgBottom, pal.bgTop},
                new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
        lp.setStrokeCap(Paint.Cap.ROUND);
        core = U.glow(U.mix(pal.a, pal.c, 0.4f), false);
        boost = 0f;
    }

    private void respawn(int i, boolean initial) {
        float x, y;
        do {
            x = U.rand(-1f, 1f);
            y = U.rand(-1f, 1f);
        } while (x * x + y * y < 0.004f);
        sx[i] = x;
        sy[i] = y;
        sz[i] = initial ? U.rand(0.05f, 1f) : U.rand(0.85f, 1f);
        sc[i] = U.R.nextInt(4);
    }

    private float velocity() {
        return 0.22f + boost * 1.4f;
    }

    @Override
    protected void update(float dt, float realDt) {
        boost *= (float) Math.exp(-1.1 * realDt);
        float v = velocity();
        float f = Math.min(w, h) * 0.35f;
        float limX = w * 0.6f + 40f, limY = h * 0.6f + 40f;
        for (int i = 0; i < n; i++) {
            sz[i] -= v * dt;
            if (sz[i] < 0.03f) {
                respawn(i, false);
                continue;
            }
            if (Math.abs(sx[i] / sz[i] * f) > limX || Math.abs(sy[i] / sz[i] * f) > limY) respawn(i, false);
        }
    }

    @Override
    protected void draw(Canvas c) {
        c.drawRect(0, 0, w, h, bg);
        float cx = w / 2f - par() * w * 0.12f, cy = h * 0.45f;
        sprite(c, core, cx, cy, w * (0.5f + 0.18f * boost), 150);
        float f = Math.min(w, h) * 0.35f;
        float streak = 0.018f + velocity() * 0.09f;
        for (int i = 0; i < n; i++) {
            float z = sz[i];
            float px = cx + sx[i] / z * f, py = cy + sy[i] / z * f;
            float z2 = z + streak;
            float qx = cx + sx[i] / z2 * f, qy = cy + sy[i] / z2 * f;
            float k = 1f - z;
            lp.setStrokeWidth((0.6f + k * k * 3.2f) * scale);
            lp.setColor(U.alpha(cols[sc[i]], Math.round(40 + 215 * k)));
            c.drawLine(qx, qy, px, py, lp);
        }
    }

    @Override
    protected void onTouch(float x, float y, int action) {
        if (isPress(action)) boost = 1f;
    }
}
